﻿\# NANMUDHALVAN\_TUESDAYBATCH\_PROJECT\_FILES

PROJECT CREATED BY : Prathiba M

AU510421205035

5104 Arunai engineering college.




LOGIN DETAILS:


UNAME: admin


Password:admin




#Project Running steps:

python manage.py makemigrations

python manage.py migrate

python manage.py createsuperuser

python manage.py runserver
